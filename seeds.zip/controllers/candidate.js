let candidate = require("../modals/candidate")
let hardskill = require("../modals/hardskill");
const language = require("../modals/language");
const softskill = require("../modals/softskill");
let userModel = require("../modals/user")

exports.post_candidate = async (req, res) => {

   var profile = "";

   if (req.files) {
       var file = req.files.candidate_profile;

       if (file.mimetype == "image/jpeg" || file.mimetype == "image/png" || file.mimetype == "image/gif"||file.mimetype == "image/jpg") {

           profile = req.protocol + "://" + req.headers.host + '/uploadprofile/' + file.name;

           file.mv('public/uploadprofile/' + file.name, function (err) {

           });

       } else {
           return res.send({ message: "This format is not allowed , please upload file with '.png','.gif','.jpg'" })
       }
   }


   let { firstname, lastname, location, heighest_qualification, about,hardskills,softskills,languages} = req.body;


   if (!firstname || !lastname || !location || !heighest_qualification || !about) {

      return res.json("fill all the parameters")

   }



     
   let candidatetype="candidatetype"
   let candidatedetils = {
      candidateID: req.result.id,
      firstname: firstname,
      candidate_profile:profile,
      lastname: lastname,
      location: location,
      heighest_qualification: heighest_qualification,
      about: about,
      hardskills: hardskills,
      softskills: softskills,
      languages: languages,
      type:candidatetype
   }
   await candidate.create(candidatedetils)
      .then(async (data) => {
         await userModel.findOneAndUpdate({ _id: req.result.id }, {
            $set: {
               onboarding: true
            }
         })
      })


   return res.json("candidate successfully registered")

}


// ###################################get all the candidates###############
  
exports.get_candidates=async (req,res)=>{
      let result=await candidate.find()
      let total_candidates=result.length
      console.log(total_candidates)
      return res.send(result)
      
}
